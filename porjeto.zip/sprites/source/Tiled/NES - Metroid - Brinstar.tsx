<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="NES - Metroid - Brinstar" tilewidth="16" tileheight="16" tilecount="12000" columns="160">
 <image source="../../bmp/NES - Metroid - Brinstar.png" trans="ff00ff" width="2560" height="1200"/>
</tileset>
