<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Tileset" tilewidth="16" tileheight="16" tilecount="4" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="1">
  <image width="16" height="16" source="../../bmp/GroundA.bmp"/>
 </tile>
 <tile id="0">
  <image width="16" height="16" source="../../bmp/GroundB.bmp"/>
 </tile>
 <tile id="3">
  <image width="16" height="16" source="../../bmp/GroundC.bmp"/>
 </tile>
 <tile id="2">
  <image width="16" height="16" source="../../bmp/GroundPipeV.bmp"/>
 </tile>
</tileset>
